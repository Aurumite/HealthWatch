/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <temperature.h>

void initTemperature(){
    ADC_Start();
    ADC_StartConvert();
}

uint16 getTemperature(){
    // Read from ADC abd convert to millivolts
    return ADC_CountsTo_mVolts(0, ADC_GetResult16(0));
}