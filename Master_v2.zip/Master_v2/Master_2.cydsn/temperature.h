/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef TEMPERATURE_H
#define TEMPERATURE_H

#include <project.h>

/*Initialization for ADC
Channels: 1, mode = single
Name: ADC
Vref: VDDA (~2V)
*/
    
void initTemperature();
uint16 getTemperature();

#endif