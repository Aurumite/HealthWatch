/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <Accelerometer.h>

void putString(const char* string){
    int len = sizeof(string) / sizeof(char);
    int i;
    
    UART_1_UartPutChar('$');
    CyDelay(10);
    for(i = 0; i <= len; i++){
        UART_1_UartPutChar(string[i]);
        CyDelay(10);
    }
    UART_1_UartPutChar('~');
}

void putInt(const int32 integer){
    int len = sizeof(integer) / sizeof(char);
    int i;
    
    UART_1_UartPutChar('#');
    CyDelay(10);
    for(i = len-1; i >= 0; i--)
        UART_1_UartPutChar(integer >> (i*8));
    UART_1_UartPutChar('~');
}


int main()
{
    I2C_1_Start();
    UART_1_Start();
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    initControl();

    for(;;){       
        int all = (getX() << 16) + (getY() << 8) + getZ();
        putInt(all);
    }
}

/* [] END OF FILE */
