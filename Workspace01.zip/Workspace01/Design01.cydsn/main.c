#include "project.h"

int main(void)
{
    ADC_Start();
    ADC_StartConvert();
    int i;
    // Floats used because the calculation for m and b
    // were equating to zero.
    float V1, V2, T1, T2;
    // Need to be floats to properly calculate temperature
    float m = 0, b = 0;
    
    // Celsius Temperature
    float temp_C = 0;
    // Farneheit Temperature
    float temp_F = 0;
    // Voltage index (mVolts)
    int a[] = {1375, 1350, 1300, 1250, 1199, 1149, 1097, 
        1046, 995, 943, 891, 838, 786, 733, 680, 627, 
        574, 520, 466, 412, 358, 302};
    // Temperature index (C)
    int c[] = {-55, -50, -40, -30, -20, -10, 0, 
        10, 20, 30, 40, 50, 60, 70, 80, 90, 100,
        110, 120, 130, 140, 150};
    
    for(;;)
    {
        // Read from ADC
        uint16 temp_ADC = ADC_GetResult16(0);
        // Convert from 'ADC format' to millivolts
        
        // temperature values: typically 0x03 0xAF
        uint16 temp_mVolts = ADC_CountsTo_mVolts(0,temp_ADC);
        
        // Get the first voltage index, a[i], that is less than 
        // the current voltage reading. Also, get the previous 
        // index to know between which two indicies our reading is.
        
        for(i=0; i<sizeof(a); i++)
        {
            if (temp_mVolts > a[i])
            {
                // Voltage index below current reading
                V1 = a[i];
                // Voltage index above current reading
                V2 = a[i-1];
                
                // Temp above
                T1 = c[i];
                // Temp below
                T2 = c[i-1];
                
                // Slope calculation
                // In case we want to reduce the number
                // of variables, we can use the equation 
                // below.
                // m = (c[i-1] - c[i]) / (a[i-1] - a[i]);
                m = (float)((T1 - T2) / (V1 - V2));
                
                // Intercept calculation
                b = T1 - (m * V1);
                
                // Temperature calculation
                temp_C = m * temp_mVolts + b;
                temp_F = temp_C * (9/5) + 32; 
                break;
            }
        }
    }
}

/* [] END OF FILE */
